terraform {
  required_version = ">= 1.6.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "= 4.63.0"
    }
  }
  backend "azurerm" {
    resource_group_name  = "landing-zone-shared-tfstate-rg"
    storage_account_name = "advtfstatemcg343434"
    container_name       = "tfstate"
    key                  = "default.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = "911e746f-0030-41d8-839c-c3579ec74ee4"
}
